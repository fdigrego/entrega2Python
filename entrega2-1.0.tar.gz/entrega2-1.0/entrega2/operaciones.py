# Aqui importo las operaciones posibles
from cliente import Cliente, clientes, depositos, retiros

# agregar cientes
def agregar_cliente(cliente_id, nombre, email, saldo):
    cliente_nuevo = Cliente(cliente_id, nombre, email, saldo)
    clientes.append(cliente_nuevo)
    return cliente_nuevo

# buscar clientes
def buscar_cliente(cliente_id):
    for idx, cliente in enumerate(clientes):
        if cliente.idx == clientes.cliente_id:
            print(clientes[cliente_id])
            return idx
    return "ID de cliente no encontrado"

# borrar clientes
def borrar_cliente(cliente_id):
    if cliente_id in clientes:
        clientes.remove(cliente_id)
        f"\nCliente con ID {cliente_id} eliminado de la lista."
        return True
    return False

# mostrar clientes
def mostrar_clientes():
    pass

# depositar

# retirar