
# en este file completo el menu de operaciones
from cliente import Cliente, clientes, depositos, retiros
from operaciones import agregar_cliente, buscar_cliente, borrar_cliente, mostrar_clientes


# algunos datos de prueba
prueba = Cliente(1, "Fabian Di Gregorio", "maildefabian@mail.com", 900.1)
print(prueba)

dep1 = prueba.deposito(1269.88)
dep2 = prueba.deposito(750)
depositos.append(dep1), depositos.append(dep2)
print(f"\tDepositos : {depositos}")
ret1 = prueba.retiro(300)
ret2 = prueba.retiro(285.02)
ret3 = prueba.retiro(600)
retiros.append(ret1), retiros.append(ret2), retiros.append(ret3) 
print(f"\tRetiros   : {retiros}\n")        

print(prueba)
print(prueba.cliente_id)

# mostrar_clientes()