# Defino la clase Cliente
class Cliente:
    def __init__(self, cliente_id, nombre, email, saldo):
        self.cliente_id = cliente_id
        self.nombre = nombre
        self.email = email
        self.saldo = saldo
        self.status = "setup"
        self.movimientos = "ini"

    def __str__(self):
        return f"\nCliente ID: {self.cliente_id}\nStatus    : {self.status.upper()}\nNombre    : {self.nombre}\nEmail     : {self.email}\nSaldo  {self.movimientos}: ${self.saldo:10,.2f}"

    def deposito(self, monto):
        if monto > 0:
            self.movimientos = "mov"
            self.saldo += monto
            
            return monto
        return False

    def retiro(self, monto):
        if 0 < monto <= self.saldo:
            self.movimientos = "mov"
            self.saldo -= monto
            return monto
        return False

# Defino donde almacenar clientes y movimientos
clientes = []
depositos = []
retiros = []