# ejecucion para generar el paquete
# python3 setup.py sdist
# el comando anterior genera un file *.tar.gz que es el que debemos entregar

from setuptools import setup

setup(
    name='entrega2',
    version='1.0',
    description='Segunda pre-entrega comision 57820',
    author="Fabian Di Gregorio, Entrega 2, Comision 57820",
    author_email="fabian@unmail.com",
    packages=["entrega2"]
)
